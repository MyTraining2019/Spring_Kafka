package org.cap.boot;

import java.util.Date;

import org.cap.pojo.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;


public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Book.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		SessionFactory sessionFactory=config.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		
		Book book=new Book("Spring Ref", 2300, "Thomson Hert", new Date(),"hert@yahoo.com");
		
		Book book1=new Book("Java Complete Ref Ref", 2300, "Robert Hert", new Date(),"robert@gmail.com");
		
		
		//Transaction transaction= session.beginTransaction();
		session.beginTransaction();
		session.save(book);
		session.save(book1);
		/*Book book2=(Book) session.load(Book.class,190);
		
		System.out.println(book2);
		book2.setPrice(1200);
		*/
		//session.delete(book2);
		
		//transaction.commit();
		session.getTransaction().commit();
		session.close();
		
	}

}
