package org.cap.config;

import org.cap.pojo.Address;
import org.cap.pojo.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {

	@Bean
	@Scope("prototype")
	public Employee getEmployeeBean() {
		return new Employee(1001, "Jack");
	}
	
	@Bean
	public Address getAddressBean() {
		return new Address("12/B", "North Street", "Mumbai");
	}
	
}
