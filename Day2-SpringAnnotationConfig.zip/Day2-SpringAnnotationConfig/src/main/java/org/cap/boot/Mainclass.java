package org.cap.boot;

import org.cap.config.JavaConfig;
import org.cap.pojo.Employee;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Mainclass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
		
		Employee employee=context.getBean(Employee.class);
		Employee employee1=context.getBean(Employee.class);
		employee1.setEmpId(1234);
		
		System.out.println(employee);
		System.out.println(employee1);
	}

}
