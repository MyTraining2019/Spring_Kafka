package org.cap.pojo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Employee {
	

	private int empId;
	private String empName;
	
	@Autowired
	private Address address;
	
	public Employee() {
		System.out.println("Default Constructor");
	}
	
	
	public Employee(int empId, String empName, Address address) {
		super();
		System.out.println("Overloaded Constructor");
		this.empId = empId;
		this.empName = empName;
		this.address = address;
	}
	public Employee(int empId, String empName) {
		System.out.println("Overloaded Constructor");
		this.empId = empId;
		this.empName = empName;
	}


	public int getEmpId() {
		return empId;
	}
	
	//@Required
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", address=" + address + "]";
	}
	
	@PostConstruct
	public void init_Method() {
		System.out.println("Bean initialized");
	}
	
	@PreDestroy
	public void destroy_Method() {
		System.out.println("Bean Destroyed");
	}
	

}
