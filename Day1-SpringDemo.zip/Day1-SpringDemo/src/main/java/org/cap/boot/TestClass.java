package org.cap.boot;

import org.cap.pojo.MyCollection;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("mycoll.xml");
	MyCollection collection=(MyCollection) context.getBean("myCollection");
	
	System.out.println(collection.getEmployees());
	}

}
