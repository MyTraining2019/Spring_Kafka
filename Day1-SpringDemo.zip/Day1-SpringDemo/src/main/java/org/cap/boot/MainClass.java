package org.cap.boot;

import org.cap.pojo.Employee;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("sample.xml");
		//ApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		//ApplicationContext context=new FileSystemXmlApplicationContext("D:\\Users\\vidavid\\Desktop\\myBeans.xml");
		//XmlBeanFactory context=new XmlBeanFactory(new ClassPathResource("myBeans.xml"));
		Employee employee=(Employee)context.getBean("emp");
		Employee employee1=(Employee)context.getBean("emp");
		
		employee1.setEmpId(1234);
		
		System.out.println(employee);
		System.out.println(employee1);
		
		context.registerShutdownHook();
	}

}
