package org.cap.pojo;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {
	
	private Map<String, Object> maps;
	private Set<String> set;
	private Properties properties;
	
	
	public CollectionDemo() {
		
	}
	
	public Map<String, Object> getMaps() {
		return maps;
	}
	public void setMaps(Map<String, Object> maps) {
		this.maps = maps;
	}
	public Set<String> getSet() {
		return set;
	}
	public void setSet(Set<String> set) {
		this.set = set;
	}
	public Properties getProperties() {
		return properties;
	}
	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	@Override
	public String toString() {
		return "CollectionDemo [maps=" + maps + ", set=" + set + ", properties=" + properties + "]";
	}
	
	

}
