package org.cap.pojo;

import java.util.List;

public class MyCollection {
	
	//private List<String> names;
	
	private List<Employee> employees;
	
	public MyCollection() {
		
	}

	/*public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}*/
	
	

	@Override
	public String toString() {
		return "MyCollection [Employees=" + employees + "]";
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	

}
