package org.cap.pojo;

import org.cap.pojo.Employee;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
			Employee employee=(Employee)context.getBean("emp");
		
		
		
		System.out.println(employee);
		
		context.registerShutdownHook();
	}

}
