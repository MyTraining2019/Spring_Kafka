package org.cap.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
		SingletonBean singletonBean=(SingletonBean)context.getBean("singletonBean");
		PrototypeBean beanA=singletonBean.getPrototypeBean();
		PrototypeBean beanB=singletonBean.getPrototypeBean();
		
		System.out.println(beanA);
		System.out.println(beanB);
		
		System.out.println("Is the bean Same? " + (beanA==beanB));
		
	}

}
