package org.cap.bean;

public class PrototypeBean {
	
	private String message;
	
	public PrototypeBean() {
		System.out.println("PrototypeBean intialized!");
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
