package org.cap.bean;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SingletonBean implements ApplicationContextAware{
	
	private PrototypeBean prototypeBean;
	
	private ApplicationContext applicationContext;
	
	public  SingletonBean () {
		System.out.println("SingletonBean Intialized!");
	}

	public PrototypeBean getPrototypeBean() {
		
		PrototypeBean prototypeBean=(PrototypeBean)applicationContext.getBean("prototypeBean");
		return prototypeBean;
	}

	public void setPrototypeBean(PrototypeBean prototypeBean) {
		this.prototypeBean = prototypeBean;
	}

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext=applicationContext;
	}
	
	

}
