package org.cap.producerDemo;

import java.util.ArrayList;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class KafkaConsumerApp {

	public static void main(String[] args) {
		Properties props=new Properties();
		props.put("bootstrap.servers", "localhost:9092");
        props.put("key.deserializer", 
        		"org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", 
        		"org.apache.kafka.common.serialization.StringDeserializer");
        
        props.put("group.id", "test");
        
        KafkaConsumer<String, String> kafkaConsumer=new KafkaConsumer<String, String>(props);
        
        
        
        //Add All Topics
        ArrayList<String> topics=new ArrayList<String>();
        topics.add("cap-topic");
        topics.add("cap-topic1");
        
        kafkaConsumer.subscribe(topics);
        try {
	        while(true) {
	        	ConsumerRecords<String, String> consumerRecords= kafkaConsumer.poll(100);
	        	
	        	for(ConsumerRecord<String, String> record:consumerRecords)
	        	System.out.println(
	        			String.format("Topic: %s, Partition:%d , Offset :%d, Value : %s",
	        					record.topic(),record.partition(),record.offset(),record.value())
	        					
	        			);
	        	
	        }
        }catch (Exception e) {
			e.printStackTrace();
		}finally {
			kafkaConsumer.close();
		}
        
	}

}
