package org.cap.service;

import java.util.List;

import org.cap.model.Student;

public interface StudentService {

    List<Student> getALlStudents();

    Student insertStudent(Student student);

    void deleteStudent(int student);
}
