package org.cap.dao;

import java.util.List;

import org.cap.pojo.Book;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Qualifier("bookDao")
public class BookDaoImpl extends AbstractBookDao implements BookDao {
	
	

	@Override
	public void insertBook(Book book) {
		getSession().save(book);
	}

	@Override
	public void deleteBook(int bookId) {
		
		Book book=(Book)getSession().get(Book.class, bookId);
		if(book!=null)
			getSession().delete(book);
	}

	@Override
	public int countAllRows() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Book findBook(int bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getAllbooks() {
		List<Book> books=getSession().createQuery("from Book").list();
		return books;
	}

	
}
