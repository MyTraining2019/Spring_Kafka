package org.cap.boot;

import java.util.Date;
import java.util.List;

import org.cap.config.JavaConfig;
import org.cap.pojo.Book;
import org.cap.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
		
		BookService bookService=(BookService)context.getBean("bookService");
		
		/*Book book=new Book( "Complete ref", 12000, "Jack paul", new Date(),"jack@gmail.com");
		Book book1=new Book( "Spring ref", 235, "Robert paul", new Date(),"Robert@gmail.com");
		Book book2=new Book( "Oracle Complete ref", 1200, "Thomson Hert", new Date(),"thomson@gmail.com");
		Book book3=new Book( "Java Complete ref", 2300, "Emi Jack", new Date(),"emi@gmail.com");
		Book book4=new Book( "Angular Introduction", 4400, "Lorial Emi", new Date(),"lorial@gmail.com");
		
		
		bookService.insertBook(book);
		bookService.insertBook(book1);
		bookService.insertBook(book2);
		bookService.insertBook(book3);
		bookService.insertBook(book4);*/
		
		
		//bookService.deleteBook(2);
		
		List<Book> books= bookService.getAllbooks();
		for(Book book:books)
			System.out.println(book);
		
	}

}
